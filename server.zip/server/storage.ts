import {
  type Student,
  type InsertStudent,
  type Course,
  type InsertCourse,
  type Enrollment,
  type InsertEnrollment,
  type Grade,
  type InsertGrade,
  type Attendance,
  type InsertAttendance,
  type Prediction,
  type InsertPrediction,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Students
  getStudents(): Promise<Student[]>;
  getStudent(id: string): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: string, student: InsertStudent): Promise<Student | undefined>;
  deleteStudent(id: string): Promise<boolean>;

  // Courses
  getCourses(): Promise<Course[]>;
  getCourse(id: string): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: string, course: InsertCourse): Promise<Course | undefined>;
  deleteCourse(id: string): Promise<boolean>;

  // Enrollments
  getEnrollments(): Promise<Enrollment[]>;
  getEnrollmentsByStudent(studentId: string): Promise<Enrollment[]>;
  getEnrollmentsByCourse(courseId: string): Promise<Enrollment[]>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  deleteEnrollment(id: string): Promise<boolean>;

  // Grades
  getGrades(): Promise<Grade[]>;
  getGradesByStudent(studentId: string): Promise<Grade[]>;
  getGradesByCourse(courseId: string): Promise<Grade[]>;
  createGrade(grade: InsertGrade): Promise<Grade>;
  deleteGrade(id: string): Promise<boolean>;

  // Attendance
  getAttendance(): Promise<Attendance[]>;
  getAttendanceByStudent(studentId: string): Promise<Attendance[]>;
  getAttendanceByCourse(courseId: string): Promise<Attendance[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  deleteAttendance(id: string): Promise<boolean>;

  // Predictions
  getPredictions(): Promise<Prediction[]>;
  createPrediction(prediction: InsertPrediction): Promise<Prediction>;
}

export class MemStorage implements IStorage {
  private students: Map<string, Student>;
  private courses: Map<string, Course>;
  private enrollments: Map<string, Enrollment>;
  private grades: Map<string, Grade>;
  private attendance: Map<string, Attendance>;
  private predictions: Map<string, Prediction>;

  constructor() {
    this.students = new Map();
    this.courses = new Map();
    this.enrollments = new Map();
    this.grades = new Map();
    this.attendance = new Map();
    this.predictions = new Map();
    this.seedData();
  }

  private seedData() {
    // Seed students
    const studentData: InsertStudent[] = [
      {
        firstName: "John",
        lastName: "Doe",
        email: "john.doe@university.edu",
        enrollmentDate: "2023-09-01",
        major: "Computer Science",
        year: 3,
        phone: "(555) 123-4567",
      },
      {
        firstName: "Jane",
        lastName: "Smith",
        email: "jane.smith@university.edu",
        enrollmentDate: "2023-09-01",
        major: "Mathematics",
        year: 2,
        phone: "(555) 234-5678",
      },
      {
        firstName: "Mike",
        lastName: "Johnson",
        email: "mike.johnson@university.edu",
        enrollmentDate: "2024-01-15",
        major: "Physics",
        year: 1,
        phone: "(555) 345-6789",
      },
      {
        firstName: "Emily",
        lastName: "Brown",
        email: "emily.brown@university.edu",
        enrollmentDate: "2022-09-01",
        major: "Computer Science",
        year: 4,
        phone: "(555) 456-7890",
      },
      {
        firstName: "David",
        lastName: "Wilson",
        email: "david.wilson@university.edu",
        enrollmentDate: "2023-09-01",
        major: "Engineering",
        year: 2,
        phone: "(555) 567-8901",
      },
    ];

    studentData.forEach((data) => {
      const id = randomUUID();
      const student: Student = {
        ...data,
        id,
        createdAt: new Date(),
      };
      this.students.set(id, student);
    });

    // Seed courses
    const courseData: InsertCourse[] = [
      {
        code: "CS101",
        name: "Introduction to Programming",
        credits: 3,
        department: "Computer Science",
        semester: "Fall 2024",
        instructor: "Dr. Sarah Anderson",
      },
      {
        code: "MATH201",
        name: "Calculus II",
        credits: 4,
        department: "Mathematics",
        semester: "Fall 2024",
        instructor: "Prof. Michael Chen",
      },
      {
        code: "PHYS101",
        name: "General Physics",
        credits: 4,
        department: "Physics",
        semester: "Fall 2024",
        instructor: "Dr. Robert Lee",
      },
      {
        code: "CS202",
        name: "Data Structures",
        credits: 3,
        department: "Computer Science",
        semester: "Fall 2024",
        instructor: "Dr. Sarah Anderson",
      },
      {
        code: "ENG101",
        name: "Engineering Fundamentals",
        credits: 3,
        department: "Engineering",
        semester: "Fall 2024",
        instructor: "Prof. Jennifer White",
      },
    ];

    courseData.forEach((data) => {
      const id = randomUUID();
      const course: Course = {
        ...data,
        id,
        createdAt: new Date(),
      };
      this.courses.set(id, course);
    });

    // Seed some grades
    const studentIds = Array.from(this.students.keys());
    const courseIds = Array.from(this.courses.keys());

    if (studentIds.length > 0 && courseIds.length > 0) {
      // Add grades for first student in first course
      const gradeData = [
        {
          studentId: studentIds[0],
          courseId: courseIds[0],
          assignmentName: "Midterm Exam",
          assignmentType: "Exam",
          score: "85",
          maxScore: "100",
          weight: "30",
        },
        {
          studentId: studentIds[0],
          courseId: courseIds[0],
          assignmentName: "Final Project",
          assignmentType: "Project",
          score: "92",
          maxScore: "100",
          weight: "40",
        },
        {
          studentId: studentIds[1],
          courseId: courseIds[1],
          assignmentName: "Quiz 1",
          assignmentType: "Quiz",
          score: "78",
          maxScore: "100",
          weight: "10",
        },
      ];

      gradeData.forEach((data) => {
        const id = randomUUID();
        const grade: Grade = {
          ...data,
          id,
          submittedAt: new Date(),
        };
        this.grades.set(id, grade);
      });

      // Seed some attendance
      const attendanceData = [
        {
          studentId: studentIds[0],
          courseId: courseIds[0],
          date: "2024-11-18",
          status: "Present",
          notes: "",
        },
        {
          studentId: studentIds[0],
          courseId: courseIds[0],
          date: "2024-11-20",
          status: "Absent",
          notes: "Medical excuse",
        },
        {
          studentId: studentIds[1],
          courseId: courseIds[1],
          date: "2024-11-18",
          status: "Late",
          notes: "Arrived 10 minutes late",
        },
      ];

      attendanceData.forEach((data) => {
        const id = randomUUID();
        const attendance: Attendance = {
          ...data,
          id,
          createdAt: new Date(),
        };
        this.attendance.set(id, attendance);
      });
    }
  }

  // Students
  async getStudents(): Promise<Student[]> {
    return Array.from(this.students.values());
  }

  async getStudent(id: string): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const id = randomUUID();
    const student: Student = {
      ...insertStudent,
      id,
      createdAt: new Date(),
    };
    this.students.set(id, student);
    return student;
  }

  async updateStudent(id: string, insertStudent: InsertStudent): Promise<Student | undefined> {
    const existing = this.students.get(id);
    if (!existing) return undefined;

    const updated: Student = {
      ...insertStudent,
      id,
      createdAt: existing.createdAt,
    };
    this.students.set(id, updated);
    return updated;
  }

  async deleteStudent(id: string): Promise<boolean> {
    return this.students.delete(id);
  }

  // Courses
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async getCourse(id: string): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const id = randomUUID();
    const course: Course = {
      ...insertCourse,
      id,
      createdAt: new Date(),
    };
    this.courses.set(id, course);
    return course;
  }

  async updateCourse(id: string, insertCourse: InsertCourse): Promise<Course | undefined> {
    const existing = this.courses.get(id);
    if (!existing) return undefined;

    const updated: Course = {
      ...insertCourse,
      id,
      createdAt: existing.createdAt,
    };
    this.courses.set(id, updated);
    return updated;
  }

  async deleteCourse(id: string): Promise<boolean> {
    return this.courses.delete(id);
  }

  // Enrollments
  async getEnrollments(): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values());
  }

  async getEnrollmentsByStudent(studentId: string): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(
      (e) => e.studentId === studentId
    );
  }

  async getEnrollmentsByCourse(courseId: string): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(
      (e) => e.courseId === courseId
    );
  }

  async createEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment> {
    const id = randomUUID();
    const enrollment: Enrollment = {
      ...insertEnrollment,
      id,
      enrolledAt: new Date(),
    };
    this.enrollments.set(id, enrollment);
    return enrollment;
  }

  async deleteEnrollment(id: string): Promise<boolean> {
    return this.enrollments.delete(id);
  }

  // Grades
  async getGrades(): Promise<Grade[]> {
    return Array.from(this.grades.values());
  }

  async getGradesByStudent(studentId: string): Promise<Grade[]> {
    return Array.from(this.grades.values()).filter(
      (g) => g.studentId === studentId
    );
  }

  async getGradesByCourse(courseId: string): Promise<Grade[]> {
    return Array.from(this.grades.values()).filter(
      (g) => g.courseId === courseId
    );
  }

  async createGrade(insertGrade: InsertGrade): Promise<Grade> {
    const id = randomUUID();
    const grade: Grade = {
      ...insertGrade,
      id,
      submittedAt: new Date(),
    };
    this.grades.set(id, grade);
    return grade;
  }

  async deleteGrade(id: string): Promise<boolean> {
    return this.grades.delete(id);
  }

  // Attendance
  async getAttendance(): Promise<Attendance[]> {
    return Array.from(this.attendance.values());
  }

  async getAttendanceByStudent(studentId: string): Promise<Attendance[]> {
    return Array.from(this.attendance.values()).filter(
      (a) => a.studentId === studentId
    );
  }

  async getAttendanceByCourse(courseId: string): Promise<Attendance[]> {
    return Array.from(this.attendance.values()).filter(
      (a) => a.courseId === courseId
    );
  }

  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const id = randomUUID();
    const attendance: Attendance = {
      ...insertAttendance,
      id,
      createdAt: new Date(),
    };
    this.attendance.set(id, attendance);
    return attendance;
  }

  async deleteAttendance(id: string): Promise<boolean> {
    return this.attendance.delete(id);
  }

  // Predictions
  async getPredictions(): Promise<Prediction[]> {
    return Array.from(this.predictions.values());
  }

  async createPrediction(insertPrediction: InsertPrediction): Promise<Prediction> {
    const id = randomUUID();
    const prediction: Prediction = {
      ...insertPrediction,
      id,
      createdAt: new Date(),
    };
    this.predictions.set(id, prediction);
    return prediction;
  }
}

export const storage = new MemStorage();
