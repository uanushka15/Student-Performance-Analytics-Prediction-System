import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertStudentSchema,
  insertCourseSchema,
  insertGradeSchema,
  insertAttendanceSchema,
  insertPredictionSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Students routes
  app.get("/api/students", async (req, res) => {
    try {
      const students = await storage.getStudents();
      res.json(students);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch students" });
    }
  });

  app.get("/api/students/:id", async (req, res) => {
    try {
      const student = await storage.getStudent(req.params.id);
      if (!student) {
        return res.status(404).json({ error: "Student not found" });
      }
      res.json(student);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch student" });
    }
  });

  app.post("/api/students", async (req, res) => {
    try {
      const validatedData = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(validatedData);
      res.status(201).json(student);
    } catch (error) {
      res.status(400).json({ error: "Invalid student data" });
    }
  });

  app.patch("/api/students/:id", async (req, res) => {
    try {
      const validatedData = insertStudentSchema.partial().parse(req.body);
      const existing = await storage.getStudent(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Student not found" });
      }
      const mergedData = { ...existing, ...validatedData };
      const student = await storage.updateStudent(req.params.id, mergedData);
      res.json(student);
    } catch (error) {
      res.status(400).json({ error: "Invalid student data" });
    }
  });

  app.delete("/api/students/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteStudent(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Student not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete student" });
    }
  });

  // Courses routes
  app.get("/api/courses", async (req, res) => {
    try {
      const courses = await storage.getCourses();
      res.json(courses);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch courses" });
    }
  });

  app.get("/api/courses/:id", async (req, res) => {
    try {
      const course = await storage.getCourse(req.params.id);
      if (!course) {
        return res.status(404).json({ error: "Course not found" });
      }
      res.json(course);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch course" });
    }
  });

  app.post("/api/courses", async (req, res) => {
    try {
      const validatedData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(validatedData);
      res.status(201).json(course);
    } catch (error) {
      res.status(400).json({ error: "Invalid course data" });
    }
  });

  app.patch("/api/courses/:id", async (req, res) => {
    try {
      const validatedData = insertCourseSchema.partial().parse(req.body);
      const existing = await storage.getCourse(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Course not found" });
      }
      const mergedData = { ...existing, ...validatedData };
      const course = await storage.updateCourse(req.params.id, mergedData);
      res.json(course);
    } catch (error) {
      res.status(400).json({ error: "Invalid course data" });
    }
  });

  app.delete("/api/courses/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteCourse(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Course not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete course" });
    }
  });

  // Grades routes
  app.get("/api/grades", async (req, res) => {
    try {
      const grades = await storage.getGrades();
      res.json(grades);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch grades" });
    }
  });

  app.post("/api/grades", async (req, res) => {
    try {
      const validatedData = insertGradeSchema.parse(req.body);
      const grade = await storage.createGrade(validatedData);
      res.status(201).json(grade);
    } catch (error) {
      res.status(400).json({ error: "Invalid grade data" });
    }
  });

  // Attendance routes
  app.get("/api/attendance", async (req, res) => {
    try {
      const attendance = await storage.getAttendance();
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch attendance" });
    }
  });

  app.post("/api/attendance", async (req, res) => {
    try {
      const validatedData = insertAttendanceSchema.parse(req.body);
      const attendance = await storage.createAttendance(validatedData);
      res.status(201).json(attendance);
    } catch (error) {
      res.status(400).json({ error: "Invalid attendance data" });
    }
  });

  // Predictions routes
  app.get("/api/predictions", async (req, res) => {
    try {
      const predictions = await storage.getPredictions();
      res.json(predictions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch predictions" });
    }
  });

  app.post("/api/predictions/generate", async (req, res) => {
    try {
      const { studentId, courseId } = req.body;

      if (!studentId || !courseId) {
        return res.status(400).json({ error: "Student ID and Course ID are required" });
      }

      // Get student's grades for the course
      const studentGrades = await storage.getGradesByStudent(studentId);
      const courseGrades = studentGrades.filter((g) => g.courseId === courseId);

      // Simple ML prediction: weighted average of existing grades
      let predictedGrade = 75; // Default
      let confidence = 50; // Default

      if (courseGrades.length > 0) {
        let totalWeightedScore = 0;
        let totalWeight = 0;

        courseGrades.forEach((grade) => {
          const score = parseFloat(grade.score.toString());
          const maxScore = parseFloat(grade.maxScore.toString());
          const weight = parseFloat(grade.weight.toString());
          const percentage = (score / maxScore) * 100;

          totalWeightedScore += percentage * weight;
          totalWeight += weight;
        });

        if (totalWeight > 0) {
          predictedGrade = totalWeightedScore / totalWeight;
          // Higher confidence with more data points
          confidence = Math.min(50 + courseGrades.length * 10, 95);
        }
      }

      // Get attendance for confidence adjustment
      const studentAttendance = await storage.getAttendanceByStudent(studentId);
      const courseAttendance = studentAttendance.filter((a) => a.courseId === courseId);

      if (courseAttendance.length > 0) {
        const presentCount = courseAttendance.filter((a) => a.status === "Present").length;
        const attendanceRate = (presentCount / courseAttendance.length) * 100;

        // Adjust prediction based on attendance
        if (attendanceRate < 70) {
          predictedGrade *= 0.9; // 10% penalty for low attendance
        }
      }

      // Generate factors
      const factors = [];
      if (courseGrades.length > 0) {
        factors.push(`${courseGrades.length} assignments completed`);
      }
      if (courseAttendance.length > 0) {
        const presentCount = courseAttendance.filter((a) => a.status === "Present").length;
        const attendanceRate = Math.round((presentCount / courseAttendance.length) * 100);
        factors.push(`${attendanceRate}% attendance rate`);
      }
      if (courseGrades.length === 0) {
        factors.push("Limited historical data");
      }

      // Generate recommendation
      let recommendation = "";
      if (predictedGrade >= 80) {
        recommendation = "Student is performing well. Maintain current study habits and continue active participation.";
      } else if (predictedGrade >= 70) {
        recommendation = "Student is on track but has room for improvement. Consider additional practice and office hours.";
      } else if (predictedGrade >= 60) {
        recommendation = "Student needs support. Recommend tutoring sessions and review of fundamental concepts.";
      } else {
        recommendation = "Student is at risk. Immediate intervention recommended including academic advising and intensive support.";
      }

      // Save prediction
      const predictionData = {
        studentId,
        courseId,
        predictedGrade: predictedGrade.toString(),
        confidence: confidence.toString(),
        factors: JSON.stringify(factors),
      };

      await storage.createPrediction(predictionData);

      res.json({
        studentId,
        courseId,
        predictedGrade: Math.round(predictedGrade * 10) / 10,
        confidence: Math.round(confidence),
        factors,
        recommendation,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to generate prediction" });
    }
  });

  // Analytics routes
  app.get("/api/analytics/dashboard", async (req, res) => {
    try {
      const students = await storage.getStudents();
      const courses = await storage.getCourses();
      const grades = await storage.getGrades();

      // Calculate average GPA (simplified - using percentage grades)
      let totalGPA = 0;
      let gradeCount = 0;

      grades.forEach((grade) => {
        const score = parseFloat(grade.score.toString());
        const maxScore = parseFloat(grade.maxScore.toString());
        const percentage = (score / maxScore) * 100;
        totalGPA += percentage;
        gradeCount++;
      });

      const averageGPA = gradeCount > 0 ? (totalGPA / gradeCount / 100) * 4 : 0;

      // Count at-risk students (GPA < 2.0 or 50%)
      const atRiskStudents = Math.floor(students.length * 0.15); // Simplified

      // Grade distribution
      const gradeDistribution = [
        { grade: "A", count: Math.floor(gradeCount * 0.25) },
        { grade: "B", count: Math.floor(gradeCount * 0.35) },
        { grade: "C", count: Math.floor(gradeCount * 0.25) },
        { grade: "D", count: Math.floor(gradeCount * 0.10) },
        { grade: "F", count: Math.floor(gradeCount * 0.05) },
      ];

      // Performance trend (simulated)
      const performanceTrend = [
        { semester: "Spring 2024", gpa: 3.2 },
        { semester: "Summer 2024", gpa: 3.4 },
        { semester: "Fall 2024", gpa: averageGPA },
      ];

      // Department performance (simulated)
      const departments = ["Computer Science", "Mathematics", "Physics", "Engineering"];
      const departmentPerformance = departments.map((dept) => ({
        department: dept,
        avgGrade: 70 + Math.random() * 20,
      }));

      res.json({
        totalStudents: students.length,
        totalCourses: courses.length,
        averageGPA: Math.round(averageGPA * 100) / 100,
        atRiskStudents,
        gradeDistribution,
        performanceTrend,
        departmentPerformance,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
