import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { type Student, type Course, type Prediction } from "@shared/schema";
import { TrendingUp, Brain, Target, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

const predictionFormSchema = z.object({
  studentId: z.string().min(1, "Please select a student"),
  courseId: z.string().min(1, "Please select a course"),
});

type PredictionForm = z.infer<typeof predictionFormSchema>;

interface PredictionResult {
  studentId: string;
  courseId: string;
  predictedGrade: number;
  confidence: number;
  factors: string[];
  recommendation: string;
}

export default function Predictions() {
  const [predictionResult, setPredictionResult] = useState<PredictionResult | null>(null);
  const { toast } = useToast();

  const { data: students } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const { data: recentPredictions } = useQuery<Prediction[]>({
    queryKey: ["/api/predictions"],
  });

  const form = useForm<PredictionForm>({
    resolver: zodResolver(predictionFormSchema),
    defaultValues: {
      studentId: "",
      courseId: "",
    },
  });

  const predictMutation = useMutation({
    mutationFn: (data: PredictionForm) =>
      apiRequest("POST", "/api/predictions/generate", data),
    onSuccess: (data: PredictionResult) => {
      setPredictionResult(data);
      queryClient.invalidateQueries({ queryKey: ["/api/predictions"] });
      toast({ title: "Prediction generated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to generate prediction", variant: "destructive" });
    },
  });

  const onSubmit = (data: PredictionForm) => {
    predictMutation.mutate(data);
  };

  const getStudentName = (studentId: string) => {
    const student = students?.find((s) => s.id === studentId);
    return student ? `${student.firstName} ${student.lastName}` : "Unknown";
  };

  const getCourseInfo = (courseId: string) => {
    const course = courses?.find((c) => c.id === courseId);
    return course ? { code: course.code, name: course.name } : { code: "N/A", name: "Unknown" };
  };

  const getGradeLabel = (grade: number) => {
    if (grade >= 90) return { label: "A", color: "text-green-600 dark:text-green-400" };
    if (grade >= 80) return { label: "B", color: "text-blue-600 dark:text-blue-400" };
    if (grade >= 70) return { label: "C", color: "text-yellow-600 dark:text-yellow-400" };
    if (grade >= 60) return { label: "D", color: "text-orange-600 dark:text-orange-400" };
    return { label: "F", color: "text-red-600 dark:text-red-400" };
  };

  const getConfidenceLevel = (confidence: number) => {
    if (confidence >= 80) return { label: "High", color: "text-green-600 dark:text-green-400" };
    if (confidence >= 60) return { label: "Moderate", color: "text-yellow-600 dark:text-yellow-400" };
    return { label: "Low", color: "text-orange-600 dark:text-orange-400" };
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Grade Predictions</h1>
        <p className="text-muted-foreground">
          Use machine learning to predict student performance and identify at-risk students
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Prediction Form */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-primary" />
              Generate Prediction
            </CardTitle>
            <CardDescription>
              Select a student and course to predict final grade
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="studentId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Student</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-student">
                            <SelectValue placeholder="Select student" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {students?.map((student) => (
                            <SelectItem key={student.id} value={student.id}>
                              {student.firstName} {student.lastName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="courseId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Course</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-course">
                            <SelectValue placeholder="Select course" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {courses?.map((course) => (
                            <SelectItem key={course.id} value={course.id}>
                              {course.code} - {course.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full"
                  disabled={predictMutation.isPending}
                  data-testid="button-generate-prediction"
                >
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Generate Prediction
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Prediction Results */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              Prediction Results
            </CardTitle>
            <CardDescription>
              AI-generated performance forecast based on historical data
            </CardDescription>
          </CardHeader>
          <CardContent>
            {predictMutation.isPending ? (
              <div className="space-y-4">
                <Skeleton className="h-32 w-full" />
                <Skeleton className="h-24 w-full" />
              </div>
            ) : predictionResult ? (
              <div className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground">
                        Predicted Grade
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-baseline gap-2">
                        <span className="text-4xl font-bold">
                          {predictionResult.predictedGrade.toFixed(1)}%
                        </span>
                        <Badge className={getGradeLabel(predictionResult.predictedGrade).color}>
                          {getGradeLabel(predictionResult.predictedGrade).label}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground">
                        Confidence Level
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-baseline gap-2">
                          <span className="text-4xl font-bold">
                            {predictionResult.confidence.toFixed(0)}%
                          </span>
                          <Badge className={getConfidenceLevel(predictionResult.confidence).color}>
                            {getConfidenceLevel(predictionResult.confidence).label}
                          </Badge>
                        </div>
                        <Progress value={predictionResult.confidence} className="h-2" />
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <h4 className="text-sm font-semibold mb-3">Contributing Factors</h4>
                  <div className="flex flex-wrap gap-2">
                    {predictionResult.factors.map((factor, index) => (
                      <Badge key={index} variant="secondary">
                        {factor}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Recommendation:</strong> {predictionResult.recommendation}
                  </AlertDescription>
                </Alert>
              </div>
            ) : (
              <div className="text-center py-12">
                <Brain className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No prediction generated</h3>
                <p className="text-muted-foreground">
                  Select a student and course to generate a grade prediction
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Predictions */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Predictions</CardTitle>
          <CardDescription>
            View recently generated predictions and their outcomes
          </CardDescription>
        </CardHeader>
        <CardContent>
          {recentPredictions && recentPredictions.length > 0 ? (
            <div className="space-y-4">
              {recentPredictions.slice(0, 5).map((prediction) => {
                const gradeInfo = getGradeLabel(parseFloat(prediction.predictedGrade.toString()));
                return (
                  <div
                    key={prediction.id}
                    className="flex items-center justify-between p-4 border rounded-md hover-elevate"
                    data-testid={`prediction-${prediction.id}`}
                  >
                    <div className="flex-1">
                      <div className="font-medium">
                        {getStudentName(prediction.studentId)}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {getCourseInfo(prediction.courseId).code} - {getCourseInfo(prediction.courseId).name}
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-2xl font-bold">
                          {parseFloat(prediction.predictedGrade.toString()).toFixed(1)}%
                        </div>
                        <Badge className={gradeInfo.color}>{gradeInfo.label}</Badge>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Confidence</div>
                        <div className="font-medium">
                          {parseFloat(prediction.confidence.toString()).toFixed(0)}%
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              No recent predictions available
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
